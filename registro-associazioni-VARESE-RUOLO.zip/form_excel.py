import tkinter as tk
from tkinter import messagebox
import os
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font
from datetime import datetime

FILE_EXCEL = "associazioni.xlsx"

def salva_su_excel():
    nome = entry_nome.get().strip()
    associazione = entry_associazione.get().strip()
    cellulare = entry_cellulare.get().strip()
    ruolo = entry_ruolo.get().strip()

    if not nome:
        messagebox.showerror("Errore", "Inserisci Nome e Cognome!")
        return
    if not associazione:
        messagebox.showerror("Errore", "Inserisci l'Associazione!")
        return
    if not cellulare:
        messagebox.showerror("Errore", "Inserisci il Cellulare!")
        return
    if not ruolo:
        messagebox.showerror("Errore", "Inserisci il Ruolo!")
        return

    if not os.path.exists(FILE_EXCEL):
        wb = Workbook()
        ws = wb.active
        ws.title = "Iscritti"
        ws.append(["Data", "Nome e Cognome", "Associazione", "Cellulare", "Ruolo"])
        for col in range(1, 6):
            ws.cell(row=1, column=col).font = Font(bold=True)
        ws.column_dimensions['A'].width = 18
        ws.column_dimensions['B'].width = 25
        ws.column_dimensions['C'].width = 30
        ws.column_dimensions['D'].width = 18
        ws.column_dimensions['E'].width = 22
        wb.save(FILE_EXCEL)

    wb = load_workbook(FILE_EXCEL)
    ws = wb.active
    ws.append([datetime.now().strftime("%d/%m/%Y %H:%M"), nome, associazione, cellulare, ruolo])
    wb.save(FILE_EXCEL)

    messagebox.showinfo("Salvato!", f"{nome} - {ruolo} salvato!")
    entry_nome.delete(0, tk.END)
    entry_associazione.delete(0, tk.END)
    entry_cellulare.delete(0, tk.END)
    entry_ruolo.delete(0, tk.END)

root = tk.Tk()
root.title("Form Associazioni -> Excel")
root.geometry("460x430")
root.configure(bg="#f5f5f5")

tk.Label(root, text="REGISTRO ASSOCIAZIONI", font=("Arial", 14, "bold"), bg="#f5f5f5").pack(pady=15)

frame = tk.Frame(root, bg="#f5f5f5")
frame.pack(padx=25, pady=5, fill="x")

tk.Label(frame, text="Nome e Cognome *", bg="#f5f5f5", anchor="w", font=("Arial", 10, "bold")).pack(fill="x")
entry_nome = tk.Entry(frame, font=("Arial", 11))
entry_nome.pack(fill="x", pady=(0,10), ipady=4)

tk.Label(frame, text="Associazione *", bg="#f5f5f5", anchor="w", font=("Arial", 10, "bold")).pack(fill="x")
entry_associazione = tk.Entry(frame, font=("Arial", 11))
entry_associazione.pack(fill="x", pady=(0,10), ipady=4)

tk.Label(frame, text="Cellulare *", bg="#f5f5f5", anchor="w", font=("Arial", 10, "bold")).pack(fill="x")
entry_cellulare = tk.Entry(frame, font=("Arial", 11))
entry_cellulare.pack(fill="x", pady=(0,10), ipady=4)

tk.Label(frame, text="Ruolo *", bg="#f5f5f5", anchor="w", font=("Arial", 10, "bold")).pack(fill="x")
entry_ruolo = tk.Entry(frame, font=("Arial", 11))
entry_ruolo.pack(fill="x", pady=(0,15), ipady=4)

tk.Button(root, text="SALVA SU EXCEL", command=salva_su_excel, bg="#217346", fg="white", font=("Arial", 11, "bold"), height=2, width=25, cursor="hand2").pack(pady=10)
tk.Label(root, text=f"File: {FILE_EXCEL}", bg="#f5f5f5", fg="gray", font=("Arial", 8)).pack(side="bottom", pady=10)

root.mainloop()
