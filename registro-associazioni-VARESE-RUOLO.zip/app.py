
import streamlit as st
import pandas as pd
import os
from datetime import datetime
from PIL import Image

FILE_EXCEL = "associazioni.xlsx"
st.set_page_config(page_title="Registro Associazioni Varese", page_icon="📋", layout="centered")

logo_path = "logo.png"
if os.path.exists(logo_path):
    st.image(logo_path, width=180)

st.title("VOLONTARIATO - Sezione di VARESE")
st.subheader("Protezione Civile - A.N.A. Alpini")

if not os.path.exists(FILE_EXCEL):
    df_init = pd.DataFrame(columns=["Data","Nome e Cognome","Associazione","Cellulare","Ruolo"])
    df_init.to_excel(FILE_EXCEL, index=False)

with st.form("form"):
    nome = st.text_input("Nome e Cognome *")
    associazione = st.text_input("Associazione *")
    cellulare = st.text_input("Cellulare *")
    ruolo = st.selectbox("Ruolo *", ["Volontario", "Caposquadra", "Coordinatore", "Autista", "Operatore Radio", "Logistica", "Segreteria", "Altro"])
    ruolo_altro = ""
    if ruolo == "Altro":
        ruolo_altro = st.text_input("Specifica Ruolo")
    submitted = st.form_submit_button("SALVA SU EXCEL", use_container_width=True)

    if submitted:
        ruolo_finale = ruolo_altro if ruolo == "Altro" and ruolo_altro else ruolo
        if not nome or not associazione or not cellulare or not ruolo_finale:
            st.error("Compila tutti i campi!")
        else:
            df = pd.read_excel(FILE_EXCEL) if os.path.exists(FILE_EXCEL) and os.path.getsize(FILE_EXCEL) > 0 else pd.DataFrame(columns=["Data","Nome e Cognome","Associazione","Cellulare","Ruolo"])
            nuova_riga = {
                "Data": datetime.now().strftime("%d/%m/%Y %H:%M"),
                "Nome e Cognome": nome,
                "Associazione": associazione,
                "Cellulare": cellulare,
                "Ruolo": ruolo_finale
            }
            df = pd.concat([df, pd.DataFrame([nuova_riga])], ignore_index=True)
            df.to_excel(FILE_EXCEL, index=False)
            st.success(f"Salvato {nome} - {ruolo_finale}!")
            st.balloons()

if os.path.exists(FILE_EXCEL):
    df = pd.read_excel(FILE_EXCEL)
    st.subheader(f"Iscritti: {len(df)}")
    st.dataframe(df, use_container_width=True)
    with open(FILE_EXCEL, "rb") as f:
        st.download_button("📥 Scarica Excel", f, file_name="associazioni.xlsx", use_container_width=True)
